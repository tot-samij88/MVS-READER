import 'package:flutter/material.dart';

class NotesProvider extends ChangeNotifier {
  final List<String> _notes = [];

  List<String> get notes => _notes;

  void addNote(String text) {
    _notes.add(text);
    notifyListeners();
  }

  void removeNote(int index) {
    _notes.removeAt(index);
    notifyListeners();
  }
}

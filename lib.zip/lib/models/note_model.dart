class Note {
  final String id;
  final String text;
  final DateTime createdAt;

  Note({
    required this.id,
    required this.text,
    required this.createdAt,
  });

  Map<String, dynamic> toJson() => {
    'id': id,
    'text': text,
    'createdAt': createdAt.toIso8601String(),
  };

  factory Note.fromJson(Map<String, dynamic> json) => Note(
    id: json['id'],
    text: json['text'],
    createdAt: DateTime.parse(json['createdAt']),
  );
}

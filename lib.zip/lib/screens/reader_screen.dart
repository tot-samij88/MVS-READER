import 'dart:convert';
import 'package:epub_view/epub_view.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import 'package:mvs_reader/providers/notes_provider.dart';

class ReaderScreen extends StatefulWidget {
  const ReaderScreen({super.key});

  @override
  State<ReaderScreen> createState() => _ReaderScreenState();
}

class _ReaderScreenState extends State<ReaderScreen> {
  late EpubController _epubController;
  List<dynamic> _chapters = [];
  final GlobalKey _textKey = GlobalKey();
  final ScrollController _scrollController = ScrollController();
  TextSelection? _selection;

  @override
  void initState() {
    super.initState();
    _loadBook();
    _loadChapters();
  }

  Future<void> _loadBook() async {
    final bytes = await rootBundle.load('assets/TEST.epub');
    _epubController = EpubController(
      document: EpubReader.readBook(bytes.buffer.asUint8List()),
    );
    setState(() {});
  }

  Future<void> _loadChapters() async {
    final jsonString = await rootBundle.loadString('assets/chapters.json');
    final parsed = json.decode(jsonString);
    setState(() {
      _chapters = parsed['chapters'];
    });
  }

  void _onSearch(String query) {
    // TODO: Реалізувати пошук
  }

  void _handleTap(Offset tapPosition, BuildContext context) {
    final width = MediaQuery.of(context).size.width;
    final dx = tapPosition.dx;
    if (dx < width / 3) {
      _scrollController.animateTo(
        _scrollController.offset - 300,
        duration: const Duration(milliseconds: 300),
        curve: Curves.easeOut,
      );
    } else if (dx > 2 * width / 3) {
      _scrollController.animateTo(
        _scrollController.offset + 300,
        duration: const Duration(milliseconds: 300),
        curve: Curves.easeOut,
      );
    }
  }

  void _handleSelection(BuildContext context) async {
    final selection = await showDialog<String>(
      context: context,
      builder: (context) {
        final controller = TextEditingController();
        return AlertDialog(
          title: const Text('Зберегти виділене'),
          content: TextField(
            controller: controller,
            maxLines: 10,
            decoration: const InputDecoration(
              hintText: 'Вставте сюди текст або підтвердьте виділене',
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context, null),
              child: const Text('Скасувати'),
            ),
            ElevatedButton(
              onPressed: () => Navigator.pop(context, controller.text),
              child: const Text('Зберегти'),
            ),
          ],
        );
      },
    );

    if (selection != null && selection.trim().isNotEmpty) {
      final notesProvider = Provider.of<NotesProvider>(context, listen: false);
      notesProvider.addNote(selection.trim());
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Нотатку збережено')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final notesProvider = Provider.of<NotesProvider>(context);

    return Scaffold(
      appBar: AppBar(
        title: const Text("Reader"),
        actions: [
          IconButton(
            icon: const Icon(Icons.notes),
            onPressed: () => Navigator.pushNamed(context, '/notes'),
          ),
        ],
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(60),
          child: Padding(
            padding: const EdgeInsets.all(8),
            child: TextField(
              decoration: InputDecoration(
                hintText: 'Пошук...',
                prefixIcon: const Icon(Icons.search),
                border: const OutlineInputBorder(),
              ),
              onSubmitted: _onSearch,
            ),
          ),
        ),
      ),
      drawer: Drawer(
        child: ListView(
          children: _chapters.map((chapter) {
            return ListTile(
              title: Text(chapter['title']),
              onTap: () {
                _epubController.gotoEpubCfi(chapter['cfi']);
                Navigator.pop(context);
              },
            );
          }).toList(),
        ),
      ),
      body: _epubController == null
          ? const Center(child: CircularProgressIndicator())
          : GestureDetector(
        onTapUp: (details) => _handleTap(details.localPosition, context),
        onLongPress: () => _handleSelection(context),
        child: SingleChildScrollView(
          controller: _scrollController,
          child: Container(
            padding: const EdgeInsets.all(16),
            child: EpubView(
              controller: _epubController,
            ),
          ),
        ),
      ),
    );
  }
}

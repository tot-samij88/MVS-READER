import 'package:flutter/material.dart';
import 'package:mvs_reader/screens/reader_screen.dart';
import 'package:mvs_reader/screens/notes_screen.dart';
import 'package:mvs_reader/providers/notes_provider.dart';
import 'package:provider/provider.dart';

void main() {
  runApp(
    ChangeNotifierProvider(
      create: (_) => NotesProvider(),
      child: const MvsReaderApp(),
    ),
  );
}

class MvsReaderApp extends StatelessWidget {
  const MvsReaderApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'MVS Reader',
      theme: ThemeData(
        primarySwatch: Colors.indigo,
        useMaterial3: true,
      ),
      initialRoute: '/',
      routes: {
        '/': (_) => const ReaderScreen(),
        '/notes': (_) => const NotesScreen(),
      },
    );
  }
}